/*
   Object being tested
 */

/* exported divide */
function divide(a,b)
{
  return a / b;
}

