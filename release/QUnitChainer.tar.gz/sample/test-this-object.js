/*
   Object being tested
 */

function divide(a,b)
{
  return a / b;
}

